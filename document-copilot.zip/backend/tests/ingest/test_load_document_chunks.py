from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest
from postgrest.exceptions import APIError

from ingest.chunking import ChunkRecord
from ingest.load_document_chunks import (
    INSERT_BATCH_SIZE,
    chunk_rows,
    enrich_filing,
    insert_document_chunk_rows,
)


def test_enrich_filing_adds_fiscal_year():
    filing = {
        "ticker": "AAPL",
        "form": "10-K",
        "filing_date": "2025-10-31",
        "report_date": "2025-09-27",
        "accession_number": "0000320193-25-000079",
        "local_path": "2025/aapl.md",
    }
    enriched = enrich_filing(filing)
    assert enriched["fiscal_year"] == "2025"


def test_chunk_rows_aligns_records_and_embeddings():
    record = ChunkRecord(
        chunk_index=0,
        text="Sample text",
        embedding_text="Sample text",
        token_count=2,
        page=None,
        section="Item 1",
        chunk_metadata={"ticker": "TEST"},
    )
    rows = chunk_rows("doc-id", [record], [[0.1, 0.2]])
    assert len(rows) == 1
    assert rows[0]["document_id"] == "doc-id"
    assert rows[0]["chunk_index"] == 0
    assert rows[0]["embedding"] == [0.1, 0.2]


def _sample_row(chunk_index: int) -> dict[str, object]:
    return {
        "id": f"id-{chunk_index}",
        "document_id": "doc-id",
        "chunk_index": chunk_index,
        "page": None,
        "section": "Item 1",
        "text": f"chunk {chunk_index}",
        "embedding": [0.1, 0.2],
        "token_count": 2,
        "chunk_metadata": {"ticker": "TEST"},
    }


@pytest.mark.anyio
async def test_insert_document_chunk_rows_batches_inserts():
    rows = [_sample_row(index) for index in range(INSERT_BATCH_SIZE + 5)]
    execute = AsyncMock()
    table = SimpleNamespace(insert=lambda batch: SimpleNamespace(execute=execute))
    client = SimpleNamespace(table=lambda name: table)

    inserted = await insert_document_chunk_rows(client, "doc-id", rows)

    assert inserted == len(rows)
    assert execute.await_count == 2


@pytest.mark.anyio
async def test_insert_document_chunk_rows_retries_timeout():
    rows = [_sample_row(0)]
    execute = AsyncMock(
        side_effect=[
            APIError({"message": "canceling statement due to statement timeout", "code": "57014"}),
            None,
        ]
    )
    table = SimpleNamespace(insert=lambda batch: SimpleNamespace(execute=execute))
    client = SimpleNamespace(table=lambda name: table)

    with patch("ingest.load_document_chunks.asyncio.sleep", new=AsyncMock()):
        inserted = await insert_document_chunk_rows(client, "doc-id", rows)

    assert inserted == 1
    assert execute.await_count == 2


@pytest.mark.anyio
async def test_insert_document_chunk_rows_rolls_back_on_failure():
    rows = [_sample_row(0)]
    execute = AsyncMock(
        side_effect=APIError(
            {"message": "canceling statement due to statement timeout", "code": "57014"}
        )
    )
    delete_execute = AsyncMock()
    table = SimpleNamespace(
        insert=lambda batch: SimpleNamespace(execute=execute),
        delete=lambda: SimpleNamespace(
            eq=lambda *args, **kwargs: SimpleNamespace(execute=delete_execute)
        ),
    )
    client = SimpleNamespace(table=lambda name: table)

    with patch("ingest.load_document_chunks.asyncio.sleep", new=AsyncMock()):
        with pytest.raises(APIError):
            await insert_document_chunk_rows(client, "doc-id", rows)

    delete_execute.assert_awaited_once()
