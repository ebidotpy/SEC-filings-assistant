from fastapi import APIRouter, Depends

from app.auth.dependencies import get_current_user

# All product routes (auth profile, chat, retrieval) register here so JWT
# verification runs before any handler — including future chat/retrieval work.
protected_router = APIRouter(dependencies=[Depends(get_current_user)])
