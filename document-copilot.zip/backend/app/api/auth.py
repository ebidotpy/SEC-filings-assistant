from uuid import UUID

from pydantic import BaseModel

from app.auth.dependencies import CurrentUser
from app.api.router import protected_router

router = protected_router


class MeResponse(BaseModel):
    id: UUID
    email: str


@router.get("/me", tags=["auth"])
async def me(user: CurrentUser) -> MeResponse:
    return MeResponse(id=user.id, email=user.email)
