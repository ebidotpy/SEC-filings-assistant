from supabase import AsyncClient, AsyncClientOptions, create_async_client

from app.config import settings


_service_role_client: AsyncClient | None = None


def _bearer_headers(access_token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {access_token}"}


async def create_user_client(access_token: str) -> AsyncClient:
    """Create a Supabase client that executes under the caller's RLS scope."""
    return await create_async_client(
        settings.supabase_url,
        settings.supabase_anon_key,
        options=AsyncClientOptions(headers=_bearer_headers(access_token)),
    )


async def get_service_role_client() -> AsyncClient:
    """Return the service-role Supabase client for trusted backend jobs."""
    global _service_role_client

    if _service_role_client is None:
        _service_role_client = await create_async_client(
            settings.supabase_url,
            settings.supabase_service_role_key,
        )

    return _service_role_client
