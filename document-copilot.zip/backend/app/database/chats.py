from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any
from uuid import UUID, uuid4

from app.database.supabase import get_service_role_client

DEFAULT_THREAD_TITLE = "New chat"


@dataclass(frozen=True, slots=True)
class ThreadRow:
    id: UUID
    user_id: UUID
    title: str
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class CitationRow:
    id: UUID
    message_id: UUID
    chunk_id: UUID
    citation_index: int
    excerpt: str
    ticker: str
    company_name: str | None
    form: str
    filing_date: date
    page: str | None
    section: str | None


@dataclass(frozen=True, slots=True)
class MessageRow:
    id: UUID
    thread_id: UUID
    role: str
    content: str | None
    parts: list[dict[str, Any]] | None
    sequence: int
    created_at: datetime
    citations: list[CitationRow] | None = None


@dataclass(frozen=True, slots=True)
class CitationInsert:
    citation_index: int
    chunk_id: UUID
    excerpt: str
    ticker: str
    company_name: str | None
    form: str
    filing_date: date
    page: str | None
    section: str | None


def _parse_thread(row: dict[str, Any]) -> ThreadRow:
    return ThreadRow(
        id=UUID(row["id"]),
        user_id=UUID(row["user_id"]),
        title=row["title"],
        created_at=datetime.fromisoformat(row["created_at"].replace("Z", "+00:00")),
        updated_at=datetime.fromisoformat(row["updated_at"].replace("Z", "+00:00")),
    )


def _parse_citation(row: dict[str, Any]) -> CitationRow:
    return CitationRow(
        id=UUID(row["id"]),
        message_id=UUID(row["message_id"]),
        chunk_id=UUID(row["chunk_id"]),
        citation_index=row["citation_index"],
        excerpt=row["excerpt"],
        ticker=row["ticker"],
        company_name=row.get("company_name"),
        form=row["form"],
        filing_date=date.fromisoformat(row["filing_date"]),
        page=row.get("page"),
        section=row.get("section"),
    )


def _parse_message(row: dict[str, Any]) -> MessageRow:
    return MessageRow(
        id=UUID(row["id"]),
        thread_id=UUID(row["thread_id"]),
        role=row["role"],
        content=row.get("content"),
        parts=row.get("parts"),
        sequence=row["sequence"],
        created_at=datetime.fromisoformat(row["created_at"].replace("Z", "+00:00")),
    )


async def list_threads(user_id: UUID) -> list[ThreadRow]:
    client = await get_service_role_client()
    response = await (
        client.table("chat_threads")
        .select("*")
        .eq("user_id", str(user_id))
        .order("updated_at", desc=True)
        .execute()
    )
    return [_parse_thread(row) for row in response.data]


async def create_thread(user_id: UUID, title: str = DEFAULT_THREAD_TITLE) -> ThreadRow:
    client = await get_service_role_client()
    thread_id = uuid4()
    response = await (
        client.table("chat_threads")
        .insert(
            {
                "id": str(thread_id),
                "user_id": str(user_id),
                "title": title,
            }
        )
        .execute()
    )
    return _parse_thread(response.data[0])


async def get_thread_raw(thread_id: UUID) -> ThreadRow | None:
    client = await get_service_role_client()
    response = await (
        client.table("chat_threads")
        .select("*")
        .eq("id", str(thread_id))
        .maybe_single()
        .execute()
    )
    if response.data is None:
        return None
    return _parse_thread(response.data)


async def list_messages(thread_id: UUID) -> list[MessageRow]:
    client = await get_service_role_client()
    response = await (
        client.table("chat_messages")
        .select("*")
        .eq("thread_id", str(thread_id))
        .order("sequence")
        .execute()
    )
    messages = [_parse_message(row) for row in response.data]
    if not messages:
        return messages

    message_ids = [str(message.id) for message in messages]
    citations_response = await (
        client.table("message_citations")
        .select("*")
        .in_("message_id", message_ids)
        .order("citation_index")
        .execute()
    )
    citations_by_message: dict[UUID, list[CitationRow]] = {}
    for row in citations_response.data:
        citation = _parse_citation(row)
        citations_by_message.setdefault(citation.message_id, []).append(citation)

    return [
        MessageRow(
            id=message.id,
            thread_id=message.thread_id,
            role=message.role,
            content=message.content,
            parts=message.parts,
            sequence=message.sequence,
            created_at=message.created_at,
            citations=citations_by_message.get(message.id, []),
        )
        for message in messages
    ]


async def next_sequence(thread_id: UUID) -> int:
    messages = await list_messages(thread_id)
    if not messages:
        return 1
    return max(message.sequence for message in messages) + 1


async def insert_message(
    thread_id: UUID,
    *,
    role: str,
    content: str | None,
    parts: list[dict[str, Any]] | None,
    sequence: int,
    message_id: UUID | None = None,
) -> MessageRow:
    client = await get_service_role_client()
    response = await (
        client.table("chat_messages")
        .insert(
            {
                "id": str(message_id or uuid4()),
                "thread_id": str(thread_id),
                "role": role,
                "content": content,
                "parts": parts,
                "sequence": sequence,
            }
        )
        .execute()
    )
    return _parse_message(response.data[0])


async def insert_citations(
    message_id: UUID,
    citations: list[CitationInsert],
) -> list[CitationRow]:
    if not citations:
        return []

    client = await get_service_role_client()
    rows = [
        {
            "id": str(uuid4()),
            "message_id": str(message_id),
            "chunk_id": str(citation.chunk_id),
            "citation_index": citation.citation_index,
            "excerpt": citation.excerpt,
            "ticker": citation.ticker,
            "company_name": citation.company_name,
            "form": citation.form,
            "filing_date": citation.filing_date.isoformat(),
            "page": citation.page,
            "section": citation.section,
        }
        for citation in citations
    ]
    response = await client.table("message_citations").insert(rows).execute()
    return [_parse_citation(row) for row in response.data]


async def touch_thread(thread_id: UUID, *, title: str | None = None) -> None:
    client = await get_service_role_client()
    payload: dict[str, Any] = {"updated_at": datetime.now().astimezone().isoformat()}
    if title is not None:
        payload["title"] = title
    await client.table("chat_threads").update(payload).eq("id", str(thread_id)).execute()
