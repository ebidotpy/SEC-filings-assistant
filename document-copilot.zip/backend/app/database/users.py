from uuid import UUID

from app.database.supabase import get_service_role_client


async def ensure_app_user(user_id: UUID, email: str) -> None:
    client = await get_service_role_client()
    await (
        client.table("users")
        .upsert(
            {"id": str(user_id), "email": email},
            on_conflict="id",
        )
        .execute()
    )
