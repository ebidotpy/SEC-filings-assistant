from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import auth, chat  # noqa: F401 — registers routes on protected_router
from app.api.router import protected_router
from app.config import settings
from app.database.documents import close_db_engine, init_db_engine
from app.observability import configure_logfire, configure_logging


@asynccontextmanager
async def lifespan(_app: FastAPI):
    configure_logging()
    configure_logfire()
    await init_db_engine()
    yield
    await close_db_engine()


app = FastAPI(title="Document Copilot", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(protected_router)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
