from dataclasses import dataclass
from typing import Annotated
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from supabase import AsyncClient, create_async_client
from supabase_auth.errors import AuthApiError

from app.config import settings

_bearer = HTTPBearer(auto_error=False)
_auth_client: AsyncClient | None = None
_unauthorized_headers = {"WWW-Authenticate": "Bearer"}


@dataclass(frozen=True, slots=True)
class AuthenticatedUser:
    id: UUID
    email: str


async def _get_auth_client() -> AsyncClient:
    global _auth_client

    if _auth_client is None:
        _auth_client = await create_async_client(
            settings.supabase_url,
            settings.supabase_anon_key,
        )

    return _auth_client


async def get_current_user(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None,
        Depends(_bearer),
    ],
) -> AuthenticatedUser:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers=_unauthorized_headers,
        )

    client = await _get_auth_client()

    try:
        response = await client.auth.get_user(jwt=credentials.credentials)
    except AuthApiError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers=_unauthorized_headers,
        ) from None

    if response is None or response.user.email is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers=_unauthorized_headers,
        )

    return AuthenticatedUser(
        id=UUID(response.user.id),
        email=response.user.email,
    )


CurrentUser = Annotated[AuthenticatedUser, Depends(get_current_user)]
