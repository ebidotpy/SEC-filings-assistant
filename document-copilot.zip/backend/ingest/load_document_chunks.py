"""Chunk Markdown filings, embed passages, and write document_chunks to Supabase."""

from __future__ import annotations

import argparse
import asyncio
import json
from datetime import date
from pathlib import Path
from uuid import uuid4

import httpx
from postgrest.exceptions import APIError

from app.database.supabase import get_service_role_client
from ingest.chunking import (
    ChunkRecord,
    build_chunker,
    chunk_document,
    parse_markdown_to_docling,
)
from ingest.embeddings import embed_texts

# Params: edit these, then run from backend/:
#   uv run --group dev python ingest/load_document_chunks.py
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
MARKDOWN_DIR = REPO_ROOT / "data" / "Markdown"
MANIFEST_PATH = MARKDOWN_DIR / "manifest.json"
SKIP_EXISTING = True
INSERT_BATCH_SIZE = 25
INSERT_MAX_RETRIES = 6
INSERT_INITIAL_BACKOFF_SECONDS = 2.0
INSERT_MAX_BACKOFF_SECONDS = 60.0
INSERT_RETRYABLE_API_CODES = {"57014", "53300", "08006"}

# Derives fiscal year from report_date, or falls back to filing_date.

def fiscal_year_from_filing(filing: dict[str, str]) -> int | None:
    report_date = filing.get("report_date")
    if report_date:
        return date.fromisoformat(report_date).year
    filing_date = filing.get("filing_date")
    return date.fromisoformat(filing_date).year if filing_date else None


def load_manifest(manifest_path: Path) -> dict:
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")
    return json.loads(manifest_path.read_text(encoding="utf-8"))

#  Copies the filing dict and adds fiscal_year when known. That metadata is stored on each chunk.
def enrich_filing(filing: dict[str, str]) -> dict[str, str]:
    enriched = dict(filing)
    fiscal_year = fiscal_year_from_filing(filing)
    if fiscal_year is not None:
        enriched["fiscal_year"] = str(fiscal_year)
    return enriched

# Loads MARKDOWN_DIR / filing["local_path"], parses Markdown with Docling, runs HybridChunker, returns ChunkRecord objects (text, section, page, token count, metadata). Optional limit_chunks caps output for smoke tests.
def chunk_records_for_filing(
    filing: dict[str, str],
    *,
    limit_chunks: int | None = None,
) -> list[ChunkRecord]:
    markdown_path = MARKDOWN_DIR / filing["local_path"]
    if not markdown_path.is_file():
        raise FileNotFoundError(f"Missing Markdown file: {markdown_path}")

    doc = parse_markdown_to_docling(markdown_path)
    chunker = build_chunker()
    records = chunk_document(doc, chunker, enrich_filing(filing))
    if limit_chunks is not None:
        return records[:limit_chunks]
    return records

# Prints chunk count, token min/max/avg, how many chunks have section/page, and a sample chunk — without touching the DB or calling OpenAI.
def print_dry_run_stats(
    filing: dict[str, str],
    records: list[ChunkRecord],
) -> None:
    token_counts = [record.token_count for record in records]
    with_section = sum(1 for record in records if record.section)
    with_page = sum(1 for record in records if record.page)
    print(
        f"  {filing['ticker']} {filing['accession_number']}: "
        f"{len(records)} chunks, "
        f"tokens min={min(token_counts)} max={max(token_counts)} "
        f"avg={sum(token_counts) // len(token_counts)}, "
        f"with_section={with_section}, with_page={with_page}"
    )
    if records:
        sample = records[min(15, len(records) - 1)]
        print(f"  sample section: {sample.section!r}")
        print(f"  sample text: {sample.text[:120]!r}...")


async def get_source_document_id(client, accession_number: str) -> str | None:
    response = await (
        client.table("source_documents")
        .select("id")
        .eq("accession_number", accession_number)
        .maybe_single()
        .execute()
    )
    if response is None or response.data is None:
        return None
    return response.data["id"]


async def document_has_chunks(client, document_id: str) -> bool:
    response = await (
        client.table("document_chunks")
        .select("id")
        .eq("document_id", document_id)
        .limit(1)
        .execute()
    )
    return bool(response.data)


async def delete_document_chunks(client, document_id: str) -> None:
    await (
        client.table("document_chunks")
        .delete()
        .eq("document_id", document_id)
        .execute()
    )


def chunk_rows(
    document_id: str,
    records: list[ChunkRecord],
    embeddings: list[list[float]],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for record, embedding in zip(records, embeddings, strict=True):
        rows.append(
            {
                "id": str(uuid4()),
                "document_id": document_id,
                "chunk_index": record.chunk_index,
                "page": record.page,
                "section": record.section,
                "text": record.text,
                "embedding": embedding,
                "token_count": record.token_count,
                "chunk_metadata": record.chunk_metadata,
            }
        )
    return rows


def _is_retryable_insert_error(error: Exception) -> bool:
    if isinstance(error, APIError):
        code = str(getattr(error, "code", "") or "")
        message = str(getattr(error, "message", "") or error).lower()
        return code in INSERT_RETRYABLE_API_CODES or "timeout" in message
    return isinstance(error, httpx.HTTPError)


async def _insert_rows_with_retry(client, rows: list[dict[str, object]]) -> None:
    backoff = INSERT_INITIAL_BACKOFF_SECONDS

    for attempt in range(INSERT_MAX_RETRIES + 1):
        try:
            await client.table("document_chunks").insert(rows).execute()
            return
        except Exception as error:
            if attempt >= INSERT_MAX_RETRIES or not _is_retryable_insert_error(error):
                raise

            delay = min(max(backoff, INSERT_INITIAL_BACKOFF_SECONDS), INSERT_MAX_BACKOFF_SECONDS)
            print(
                f"Chunk insert failed ({type(error).__name__}), "
                f"retry {attempt + 1}/{INSERT_MAX_RETRIES} in {delay:.1f}s..."
            )
            await asyncio.sleep(delay)
            backoff = min(backoff * 2, INSERT_MAX_BACKOFF_SECONDS)


async def insert_document_chunk_rows(
    client,
    document_id: str,
    rows: list[dict[str, object]],
) -> int:
    if not rows:
        return 0

    inserted = 0
    try:
        for start in range(0, len(rows), INSERT_BATCH_SIZE):
            batch = rows[start : start + INSERT_BATCH_SIZE]
            await _insert_rows_with_retry(client, batch)
            inserted += len(batch)
    except Exception:
        await delete_document_chunks(client, document_id)
        raise

    return inserted


async def insert_document_chunks(
    client,
    document_id: str,
    records: list[ChunkRecord],
) -> int:
    embeddings = await embed_texts([record.embedding_text for record in records])
    rows = chunk_rows(document_id, records, embeddings)
    return await insert_document_chunk_rows(client, document_id, rows)


async def ingest_filing(
    client,
    filing: dict[str, str],
    *,
    dry_run: bool,
    limit_chunks: int | None,
    skip_existing: bool,
    force: bool,
) -> str:
    accession_number = filing["accession_number"]
    records = chunk_records_for_filing(filing, limit_chunks=limit_chunks)

    if dry_run:
        print_dry_run_stats(filing, records)
        return "dry_run"

    document_id = await get_source_document_id(client, accession_number)
    if document_id is None:
        raise ValueError(
            f"No source_documents row for accession {accession_number}. "
            "Run ingest/load_source_documents.py first."
        )

    has_chunks = await document_has_chunks(client, document_id)
    if has_chunks and skip_existing and not force:
        return "skipped"

    if has_chunks and force:
        await delete_document_chunks(client, document_id)

    inserted = await insert_document_chunks(client, document_id, records)
    print(
        f"  {filing['ticker']} {accession_number}: inserted {inserted} chunk(s)"
    )
    return "inserted"


async def load_document_chunks(
    *,
    accession_number: str | None,
    dry_run: bool,
    limit_chunks: int | None,
    skip_existing: bool,
    force: bool,
) -> dict[str, int]:
    manifest = load_manifest(MANIFEST_PATH)
    filings = manifest.get("filings", [])
    if not filings:
        raise ValueError(f"No filings listed in {MANIFEST_PATH}")

    if accession_number is not None:
        filings = [f for f in filings if f["accession_number"] == accession_number]
        if not filings:
            raise ValueError(f"Accession number not found in manifest: {accession_number}")

    client = await get_service_role_client()
    counts = {"inserted": 0, "skipped": 0, "dry_run": 0}

    for index, filing in enumerate(filings, start=1):
        print(
            f"[{index}/{len(filings)}] Processing {filing['ticker']} "
            f"{filing['accession_number']}..."
        )
        result = await ingest_filing(
            client,
            filing,
            dry_run=dry_run,
            limit_chunks=limit_chunks,
            skip_existing=skip_existing,
            force=force,
        )
        counts[result] += 1

    return counts


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Chunk Markdown filings, embed passages, and load document_chunks."
    )
    parser.add_argument(
        "--accession-number",
        help="Process a single filing by accession number.",
    )
    parser.add_argument(
        "--limit-chunks",
        type=int,
        help="Stop after N chunks per document (for smoke tests).",
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
        default=SKIP_EXISTING,
        help="Skip documents that already have chunks (default).",
    )
    parser.add_argument(
        "--no-skip-existing",
        action="store_false",
        dest="skip_existing",
        help="Re-process documents even if chunks exist (requires --force to replace).",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Delete existing chunks for a document before re-ingesting.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Chunk locally and print stats without embedding or DB writes.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = asyncio.run(
        load_document_chunks(
            accession_number=args.accession_number,
            dry_run=args.dry_run,
            limit_chunks=args.limit_chunks,
            skip_existing=args.skip_existing,
            force=args.force,
        )
    )
    print(
        "Loaded document chunks: "
        f"{result['inserted']} inserted, "
        f"{result['skipped']} skipped, "
        f"{result['dry_run']} dry-run"
    )


if __name__ == "__main__":
    main()
