type Env = {
  apiBaseUrl: string
  supabaseUrl: string
  supabaseAnonKey: string
}

function requireEnv(name: string): string {
  const value = import.meta.env[name]

  if (typeof value !== 'string' || value.trim() === '') {
    throw new Error(`Missing required environment variable: ${name}`)
  }

  return value.trim()
}

function normalizeBaseUrl(url: string): string {
  return url.endsWith('/') ? url.slice(0, -1) : url
}

export const env: Env = {
  apiBaseUrl: normalizeBaseUrl(requireEnv('VITE_API_BASE_URL')),
  supabaseUrl: requireEnv('VITE_SUPABASE_URL'),
  supabaseAnonKey: requireEnv('VITE_SUPABASE_ANON_KEY'),
}
